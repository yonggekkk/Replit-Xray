#!/bin/bash
export PATH="/home/runner/nginx/sbin:~/${REPL_SLUG}/python:$PATH"
green(){ echo -e "\033[32m\033[01m$1\033[0m";}
yellow(){ echo -e "\033[33m\033[01m$1\033[0m";}
blue(){ echo -e "\033[36m\033[01m$1\033[0m";}

if [ -z "${ver}" ]; then
wget -qO ./python/web https://github.com/yonggekkk/Replit-Xray/raw/main/web/web
else
wget -qO ./python/web https://github.com/yonggekkk/Replit-Xray/raw/main/web/web143
fi
xy=$(tr -dc 'A-Za-z0-9' </dev/urandom | head -c 6)
if [ -f "./python/xr.log" ]; then
xxy=$(cat ./python/xr.log)
rm -f ./python/$xxy 
fi
mv ./python/web ./python/$xy
echo "$xy">./python/xr.log
chmod a+x ./python/$xy ./nginx/sbin/nginx
if [ ! -d "/home/runner/nginx" ];then
\cp -ax ./nginx /home/runner/nginx
fi

uuid=${uuid:-$REPL_ID}
cp -f ./python/config.json /tmp/config.json
sed -i "s|uuid|$uuid|g" /tmp/config.json
sed -i "s|uuid|$uuid|g" /home/runner/nginx/conf/conf.d/default.conf
sed -i "s#[0-9a-f]\{8\}-[0-9a-f]\{4\}-[0-9a-f]\{4\}-[0-9a-f]\{4\}-[0-9a-f]\{12\}#$uuid#g" /tmp/config.json
sed -i "s#[0-9a-f]\{8\}-[0-9a-f]\{4\}-[0-9a-f]\{4\}-[0-9a-f]\{4\}-[0-9a-f]\{12\}#$uuid#g" /home/runner/nginx/conf/conf.d/default.conf
chmod +x ./python/cam
./python/cam tunnel --url http://localhost:8089 --edge-ip-version auto --no-autoupdate --protocol http2 > ./python/cam.log 2>&1 &
sleep 5
if [[ -n "${argotoken}" && -n "${argoym}" ]]; then
./python/cam tunnel --edge-ip-version auto --protocol http2 run --token ${argotoken} >/dev/null 2>&1 &
sleep 5
fi

if [ -z "${www}" ]; then
wwwnum=$((RANDOM % 10))  
[ $wwwnum -eq 0 ] && www="" || www=$wwwnum
rm -rf ./nginx/html/* /home/runner/nginx/html/* && wget -qP ./nginx/html/ "https://github.com/yonggekkk/doprax-xray/raw/main/3w/html${www}.zip" && unzip -o "./nginx/html/html${www}.zip" -d /home/runner/nginx/html >/dev/null 2>&1
else
rm -rf ./nginx/html/* /home/runner/nginx/html/* && wget -qP ./nginx/html/ "https://github.com/yonggekkk/doprax-xray/raw/main/3w/html${www}.zip" && unzip -o "./nginx/html/html${www}.zip" -d /home/runner/nginx/html >/dev/null 2>&1
fi
cam=$(cat ./python/cam.log | grep -a trycloudflare.com | awk 'NR==2{print}' | awk -F// '{print $2}' | awk '{print $1}') 
if [[ -n "${argotoken}" && -n "${argoym}" ]]; then
aym="Argo固定隧道域名：$argoym"
else
aym='Argo固定隧道：未设置'
fi

v1=$(echo -e '\x76\x6d\x65\x73\x73')
v2=$(echo -e '\x76\x6c\x65\x73\x73')
UA_Browser="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36"
v4=$(curl -s4m6 ip.sb -k)
v4l=$(curl -sm6 --user-agent "${UA_Browser}" http://ip-api.com/json/$v4?lang=zh-CN -k | cut -f2 -d"," | cut -f4 -d '"')
xver=$(./python/$xy version | sed -n 1p | awk '{print $2}')
url=${ym}

replitvm="vmess://$(echo -n "\
{\
\"v\": \"2\",\
\"ps\": \"replit-vmess\",\
\"add\": \"${ym}\",\
\"port\": \"443\",\
\"id\": \"$uuid\",\
\"aid\": \"0\",\
\"net\": \"ws\",\
\"type\": \"none\",\
\"host\": \"${ym}\",\
\"path\": \"/$uuid-vm\",\
\"sni\": \"${ym}\",\
\"tls\": \"tls\"\
}"\
    | base64 -w 0)"      

qrencode -o qrcode.png "${replitvm}"
vmcode=$(base64 qrcode.png)
vmcode=$(echo $vmcode)

replitvl="vless://${uuid}@${ym}:443?encryption=none&security=tls&type=ws&host=${ym}&sni=${ym}&path=/$uuid-vl#replit-vless" 

qrencode -o qrcode.png "${replitvl}"
vlcode=$(base64 qrcode.png)
vlcode=$(echo $vlcode)

replittr="trojan://${uuid}@${ym}:443?security=tls&type=ws&host=${ym}&sni=${ym}&path=/$uuid-tr#replit-trojan"

qrencode -o qrcode.png "${replittr}"
trcode=$(base64 qrcode.png)
trcode=$(echo $trcode)

cat > /home/runner/nginx/html/$uuid.html << EOF
<!DOCTYPE html>
<html>
<head>
<title>节点分享链接</title>
<style>
    body {
        width: auto;
        margin: 0 auto;
        font-family: Tahoma, Verdana, Arial, sans-serif;
    }
</style>
</head>
<body>
<p>****************************************************************</p>
<h1>教程说明</h1>
<p>视频：https://www.youtube.com/@ygkkk</p>
<p>博客：https://ygkkk.blogspot.com</p>
<p>****************************************************************</p>
<h1>当前服务器IP信息</h1>
<p>IP地址：$v4</p>
<p>IP所在地区：$v4l</p>
<p>****************************************************************</p>
<h1>Xray五大协议明文及分享链接、二维码</h1>
<p>当前Xray正式版本号：$xver</p>
<p>Argo临时隧道域名：$cam</p>
<p>$aym</p>
<p>================================================================</p>
<p>1：Vmess+ws+tls配置明文如下，相关参数可复制到客户端</p>
<p>服务器地址：$url</p>
<p>端口：443</p>
<p>uuid：$uuid</p>
<p>传输协议：ws</p>
<p>host/sni：$url</p>
<p>path路径：/$uuid-vm</p>
<p>tls：开启</p>
<p>----------------------------------------------------------------</p>
<p>Vmess链接：</p>
<p data-copy="vmess">$replitvm</p>
<button onclick="copyText('vmess')" >点击复制Vmess链接</button>
<p>----------------------------------------------------------------</p>
<p>Vmess二维码：</p>
<img src="data:image/png;base64,$vmcode"/>
<p>================================================================</p>
<p>2：Vless+ws+tls配置明文如下，相关参数可复制到客户端</p>
<p>服务器地址：$url</p>
<p>端口：443</p>
<p>uuid：$uuid</p>
<p>传输协议：ws</p>
<p>host/sni：$url</p>
<p>path路径：/$uuid-vl</p>
<p>tls：开启</p>
<p>----------------------------------------------------------------</p>
<p>Vless链接：</p>
<p data-copy="vless">$replitvl</p>
<button onclick="copyText('vless')" >点击复制Vless链接</button>
<p>----------------------------------------------------------------</p>
<p>Vless二维码：</p>
<img src="data:image/png;base64,$vlcode"/>
<p>================================================================</p>
<p>3：Trjan+ws+tls配置明文如下，相关参数可复制到客户端</p>
<p>服务器地址：$url</p>
<p>端口：443</p>
<p>密码：$uuid</p>
<p>传输协议：ws</p>
<p>host/sni：$url</p>
<p>path路径：/$uuid-tr</p>
<p>tls：开启</p>
<p>----------------------------------------------------------------</p>
<p>Trojan链接：</p>
<p data-copy="trojan">$replittr</p>
<button onclick="copyText('trojan')" >点击复制Trojan链接</button>
<p>----------------------------------------------------------------</p>
<p>Trojan二维码：</p>
<img src="data:image/png;base64,$trcode"/>
<p>================================================================</p>
<p>4：shadowsocks+ws+tls配置明文如下，相关参数可复制到客户端</p>
<p>服务器地址：$url</p>
<p>端口：443</p>
<p>密码：$uuid</p>
<p>加密方式：chacha20-ietf-poly1305</p>
<p>传输协议：ws</p>
<p>host/sni：$url</p>
<p>path路径：/$uuid-ss</p>
<p>tls：开启</p>
<p>================================================================</p>
<p>5：socks+ws+tls配置明文如下，相关参数可复制到客户端</p>
<p>服务器地址：$url</p>
<p>端口：443</p>
<p>用户名：$uuid</p>
<p>密码：$uuid</p>
<p>传输协议：ws</p>
<p>host/sni：$url</p>
<p>path路径：/$uuid-so</p>
<p>tls：开启</p>
<p>================================================================</p>
</body>
EOF
echo '<script>
      function copyText(textId) {
        var text = document.querySelector(`[data-copy="${textId}"]`).innerText;
        var textArea = document.createElement("textarea");
        textArea.value = text;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand("copy");
        document.body.removeChild(textArea);
        alert("复制成功");
      }
    </script>
</html>
' >> /home/runner/nginx/html/$uuid.html
rm -rf ./python/cam.log ./qrcode.png
if [ -n "${ym}" ]; then
echo
green "========================================="
blue "安装完毕，享受吧！"
echo "------------------------------------------"
echo "方案一：手搓5大协议各13个端口节点"
echo "Argo临时隧道域名：$cam"
echo "$aym"
echo "UUID值：$uuid"
echo "Path路径：$uuid-各协议简称(vm/vl/tr/ss/so)"
echo "------------------------------------------"
echo "方案二：点击下方节点分享网页，方便查看"
echo "https://${ym}/$uuid.html" 
echo "或"
echo "http://${ym}/$uuid.html" 
echo "------------------------------------------"
echo
yellow "最新更新日志：
2024.1.15更新：
1、重构脚本，支持Argo临时隧道与固定隧道
视频教程：https://www.youtube.com/@ygkkk
博客地址：https://ygkkk.blogspot.com"
green "========================================="
echo
else
green "========================================="
yellow "请完成以下三步操作："
yellow "一、点击右上角【New tab】选项，复制【伪装网页地址】"
yellow "二、设置Secrets，变量名称为【ym】，变量值为【伪装网页地址】"
yellow "三、点击Stop再点击Run，显示两个方案选项"
green "========================================="
fi
total_time=0
while :; do
sleep 5
total_time=$((total_time + 5))
echo -en "\r累积运行时间: ${total_time}秒"
done &
./python/$(cat ./python/xr.log) -c /tmp/config.json >/dev/null 2>&1 &
./nginx/sbin/nginx -g 'daemon off;'
tail -f
